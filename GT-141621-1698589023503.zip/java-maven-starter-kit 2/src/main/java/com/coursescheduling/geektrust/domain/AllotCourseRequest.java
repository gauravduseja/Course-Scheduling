package com.coursescheduling.geektrust.domain;

import java.util.List;

import static com.coursescheduling.geektrust.helper.Constants.FIRST_INDEX;


public class AllotCourseRequest {

    private final String courseOfferingId;


    public AllotCourseRequest(List<String> allotCourseParams) {
        this.courseOfferingId = allotCourseParams.get(FIRST_INDEX);
    }

    public String getCourseOfferingId() {
        return courseOfferingId;
    }
}
