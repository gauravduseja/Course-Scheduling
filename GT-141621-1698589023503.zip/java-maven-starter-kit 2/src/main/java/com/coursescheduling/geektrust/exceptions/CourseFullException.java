package com.coursescheduling.geektrust.exceptions;

public class CourseFullException extends Exception {

    public CourseFullException(String exceptionMessage) {
        super(exceptionMessage);
    }
}
