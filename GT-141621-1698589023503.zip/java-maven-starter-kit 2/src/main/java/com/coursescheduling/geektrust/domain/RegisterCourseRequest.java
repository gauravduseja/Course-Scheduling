package com.coursescheduling.geektrust.domain;

import java.util.List;

import static com.coursescheduling.geektrust.helper.Constants.FIRST_INDEX;
import static com.coursescheduling.geektrust.helper.Constants.SECOND_INDEX;

public class RegisterCourseRequest {

    private final String email;
    private final String courseOfferingId;

    public RegisterCourseRequest(List<String> registerCourseParams) {

        this.email = registerCourseParams.get(FIRST_INDEX);
        this.courseOfferingId = registerCourseParams.get(SECOND_INDEX);
    }

    public String getEmail() {
        return email;
    }

    public String getCourseOfferingId() {
        return courseOfferingId;
    }
}
