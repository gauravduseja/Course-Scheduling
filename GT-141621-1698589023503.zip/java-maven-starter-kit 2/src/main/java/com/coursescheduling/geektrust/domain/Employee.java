package com.coursescheduling.geektrust.domain;

import com.coursescheduling.geektrust.util.ValidationUtil;
import com.coursescheduling.geektrust.exceptions.InvalidInputException;

import static com.coursescheduling.geektrust.helper.Constants.FIRST_INDEX;


public class Employee {

    private final String email;
    private final String name;

    public Employee(String email) throws InvalidInputException {
        ValidationUtil.validateEmailAddress(email);
        this.email = email;
        this.name = email.split("@")[FIRST_INDEX];
    }

    public String getEmail() {
        return email;
    }

    public String getName() {
        return name;
    }
}
