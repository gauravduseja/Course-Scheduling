package com.coursescheduling.geektrust.service;

import com.coursescheduling.geektrust.domain.Command;
import com.coursescheduling.geektrust.exceptions.CourseFullException;
import com.coursescheduling.geektrust.exceptions.InvalidInputException;

public interface CommandExecutorService {

    void executeCommand(Command command) throws InvalidInputException, CourseFullException;
}
