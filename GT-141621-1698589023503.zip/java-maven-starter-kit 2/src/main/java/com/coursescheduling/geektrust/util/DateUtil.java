package com.coursescheduling.geektrust.util;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtil {

    public static final String DATE_TIME_FORMAT = "ddMMyyyy";

    public static String getFormattedDate(Date date, String dateFormat) {
        DateFormat df = new SimpleDateFormat(dateFormat);
        return df.format(date);
    }
}
