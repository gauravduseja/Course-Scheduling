package com.coursescheduling.geektrust.domain;

import java.util.List;

import static com.coursescheduling.geektrust.helper.Constants.FIFTH_INDEX;
import static com.coursescheduling.geektrust.helper.Constants.FIRST_INDEX;
import static com.coursescheduling.geektrust.helper.Constants.FOURTH_INDEX;
import static com.coursescheduling.geektrust.helper.Constants.SECOND_INDEX;
import static com.coursescheduling.geektrust.helper.Constants.THIRD_INDEX;


public class AddCourseRequest{

    private final String courseName;
    private final String instructor;
    private final String date;
    private final int minEmployee;
    private final int maxEmployee;

    public AddCourseRequest(List<String> addCourseParams) {

        this.courseName = addCourseParams.get(FIRST_INDEX);
        this.instructor = addCourseParams.get(SECOND_INDEX);
        this.date = addCourseParams.get(THIRD_INDEX);
        this.minEmployee = Integer.parseInt(addCourseParams.get(FOURTH_INDEX));
        this.maxEmployee = Integer.parseInt(addCourseParams.get(FIFTH_INDEX));
    }

    public String getCourseName() {
        return courseName;
    }

    public String getInstructor() {
        return instructor;
    }

    public String getDate() {
        return date;
    }

    public int getMinEmployee() {
        return minEmployee;
    }

    public int getMaxEmployee() {
        return maxEmployee;
    }
}
