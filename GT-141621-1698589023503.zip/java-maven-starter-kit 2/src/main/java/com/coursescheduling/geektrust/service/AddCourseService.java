package com.coursescheduling.geektrust.service;


import com.coursescheduling.geektrust.domain.AddCourseRequest;
import com.coursescheduling.geektrust.domain.Command;
import com.coursescheduling.geektrust.domain.Course;
import com.coursescheduling.geektrust.exceptions.InvalidInputException;
import com.coursescheduling.geektrust.repository.CourseSchedulingRepository;
import com.coursescheduling.geektrust.util.DateUtil;

import java.text.SimpleDateFormat;
import java.util.Date;

import static com.coursescheduling.geektrust.helper.Constants.DASH;
import static com.coursescheduling.geektrust.helper.Constants.INPUT_DATA_ERROR;

public class AddCourseService implements CommandExecutorService {

    private static final String OFFERING = "OFFERING";

    @Override
    public void executeCommand(Command command) throws InvalidInputException {
        Course course = createCourse(command.getCommandParams().getAddCourseRequest());
        CourseSchedulingRepository.AVAILABLE_COURSES.put(course.getId(), course); // publish course
        System.out.println(course.getId());
    }

    private Course createCourse(AddCourseRequest addCourseRequest) throws InvalidInputException {
        try {
            String courseName = addCourseRequest.getCourseName();
            String courseInstructor = addCourseRequest.getInstructor();
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat(DateUtil.DATE_TIME_FORMAT);
            Date publicationDate = simpleDateFormat.parse(addCourseRequest.getDate());
            int minEmployee = addCourseRequest.getMinEmployee();
            int maxEmployee = addCourseRequest.getMaxEmployee();

            return new Course(OFFERING + DASH + courseName + DASH + courseInstructor, courseName, courseInstructor, publicationDate,
                    minEmployee, maxEmployee, false, false);
        }
        catch (Exception e) {
            throw new InvalidInputException(INPUT_DATA_ERROR);
        }
    }
}
