package com.coursescheduling.geektrust.domain;

import java.util.HashMap;

import static com.coursescheduling.geektrust.helper.Constants.ADD_COURSE_NO_OF_ARGS_REQUIRED;
import static com.coursescheduling.geektrust.helper.Constants.ALLOT_COURSE_NO_OF_ARGS_REQUIRED;
import static com.coursescheduling.geektrust.helper.Constants.CANCEL_COURSE_NO_OF_ARGS_REQUIRED;
import static com.coursescheduling.geektrust.helper.Constants.REGISTER_COURSE_NO_OF_ARGS_REQUIRED;

public enum Command {
    ADD_COURSE_OFFERING("ADD-COURSE-OFFERING", ADD_COURSE_NO_OF_ARGS_REQUIRED),
    REGISTER("REGISTER", REGISTER_COURSE_NO_OF_ARGS_REQUIRED),
    ALLOT_COURSE("ALLOT", ALLOT_COURSE_NO_OF_ARGS_REQUIRED),
    CANCEL("CANCEL", CANCEL_COURSE_NO_OF_ARGS_REQUIRED);

    private final String command;

    private final Integer requiredNumberOfArgs;

    private CommandParams commandParams;


    Command(String command, Integer requiredNumberOfArgs) {
        this.command = command;
        this.requiredNumberOfArgs = requiredNumberOfArgs;
    }

    public String toString() {return this.command;}

    private static final HashMap<String, Command> map = new HashMap<>(values().length);

    static {
        for (Command c : values()) {
            map.put(c.command, c);
        }
    }

    public static Command of(String command) {
        return map.get(command);

    }

    public Integer getRequiredNumberOfArgs() {
        return this.requiredNumberOfArgs;
    }

    public CommandParams getCommandParams() {
        return commandParams;
    }

    public void setCommandParams(CommandParams commandParams) {
        this.commandParams = commandParams;
    }
}
