package com.coursescheduling.geektrust.domain;

import java.util.List;

import static com.coursescheduling.geektrust.helper.Constants.FIRST_INDEX;


public class CancelRegistrationRequest {

    private final String courseRegistrationId;

    public CancelRegistrationRequest(List<String> cancelRegistrationParams) {
        this.courseRegistrationId = cancelRegistrationParams.get(FIRST_INDEX);
    }

    public String getCourseRegistrationId() {
        return courseRegistrationId;
    }
}
