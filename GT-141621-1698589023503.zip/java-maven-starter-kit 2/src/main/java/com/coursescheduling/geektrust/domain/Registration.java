package com.coursescheduling.geektrust.domain;

public class Registration {

    private final String id;
    private final Course course;
    private final Employee employee;

    public Registration(String id, Course course, Employee employee) {
        this.id = id;
        this.course = course;
        this.employee = employee;
    }

    public String getId() {
        return id;
    }

    public Course getCourse() {
        return course;
    }

    public Employee getEmployee() {
        return employee;
    }
}
