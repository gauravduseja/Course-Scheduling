package com.coursescheduling.geektrust.helper;

import java.util.regex.Pattern;

public class Constants {

    public static final Pattern VALID_EMAIL_ADDRESS_REGEX =
            Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$", Pattern.CASE_INSENSITIVE);

    public static final String ACCEPTED = "ACCEPTED";
    public static final String CANCEL_REJECTED = "CANCEL_REJECTED";
    public static final String CANCEL_ACCEPTED = "CANCEL_ACCEPTED";

    public static final String DASH = "-";

    public static final String INPUT_DATA_ERROR = "INPUT_DATA_ERROR";

    public static final String COURSE_CANCELED = "COURSE_CANCELED";
    public static final String CONFIRMED = "CONFIRMED";
    
    public static final String UNSUPPORTED_INPUT_FILE = "Input file is not supplied";
    public static final String EMPTY_STRING = "";
    public static final String BLANK_SPACE = " ";

    public static final int FIRST_INDEX = 0;
    public static final int SECOND_INDEX = 1;
    public static final int THIRD_INDEX = 2;
    public static final int FOURTH_INDEX = 3;
    public static final int FIFTH_INDEX = 4;

    public static final int ADD_COURSE_NO_OF_ARGS_REQUIRED = 5; // number of argument required for add course command
    public static final int REGISTER_COURSE_NO_OF_ARGS_REQUIRED = 2; // number of argument required for register course command
    public static final int ALLOT_COURSE_NO_OF_ARGS_REQUIRED = 1; // number of argument required for allot course command
    public static final int CANCEL_COURSE_NO_OF_ARGS_REQUIRED = 1; // number of argument required for add course command
}

