package com.coursescheduling.geektrust.domain;

import java.util.Date;
import java.util.Map;
import java.util.TreeMap;

public class Course {

    private final String id;
    private final String title;
    private final String instructor;
    private final Date publicationDate;
    private final int minEmployee; // minimum number of employees for the course offering
    private final int maxEmployee; // maximum number of employees for the course offering
    private final Map<String, Employee> registeredEmployees;
    private boolean isCancelled;
    private boolean isAllotted;


    public Course(String id, String title, String instructor, Date publicationDate, int minEmployee, int maxEmployee,
                  boolean isCancelled, boolean isAllotted) {
        this.id = id;
        this.title = title;
        this.instructor = instructor;
        this.publicationDate = publicationDate;
        this.minEmployee = minEmployee;
        this.maxEmployee = maxEmployee;
        this.isCancelled = isCancelled;
        this.isAllotted = isAllotted;

        this.registeredEmployees = new TreeMap<>();
    }

    public String getTitle() {
        return title;
    }

    public String getInstructor() {
        return instructor;
    }

    public Date getPublicationDate() {
        return publicationDate;
    }

    public int getMinEmployee() {
        return minEmployee;
    }

    public int getMaxEmployee() {
        return maxEmployee;
    }

    public String getId() {
        return id;
    }

    public Map<String, Employee> getRegisteredEmployees() {
        return registeredEmployees;
    }

    public void addRegisteredEmployee(String registrationId, Employee employee) {
        this.registeredEmployees.put(registrationId, employee);
    }

    public Date getDate() {
        return publicationDate;
    }

    public boolean isAllotted() {
        return isAllotted;
    }

    public boolean isCancelled() {
        return isCancelled;
    }

    public void setAllotted(boolean allotted) {
        isAllotted = allotted;
    }

    public void setCancelled(boolean cancelled) {
        isCancelled = cancelled;
    }
}
