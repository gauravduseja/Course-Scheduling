package com.coursescheduling.geektrust.util;

import com.coursescheduling.geektrust.domain.Command;
import com.coursescheduling.geektrust.service.AddCourseService;
import com.coursescheduling.geektrust.service.AllotCourseService;
import com.coursescheduling.geektrust.service.CancelRegistrationService;
import com.coursescheduling.geektrust.service.CommandExecutorService;
import com.coursescheduling.geektrust.service.RegisterCourseService;

import java.util.Objects;

public class ApplicationUtil {

    /**
     * This method will return object of service that needs to be executed for the given input command
     * @param inputCommand - input command
     * @return - Returns object of service to be executed
     */
    public static CommandExecutorService getServiceForCommand(Command inputCommand) {
        if (Objects.isNull(inputCommand)) {
            return null;
        }

        switch (inputCommand) {
            case ADD_COURSE_OFFERING: {
                return new AddCourseService();
            }
            case REGISTER: {
                return new RegisterCourseService();
            }
            case CANCEL: {
                return new CancelRegistrationService();
            }
            case ALLOT_COURSE: {
                return new AllotCourseService();
            }
        }

        return null;
    }
}
