package com.coursescheduling.geektrust.service;

import com.coursescheduling.geektrust.domain.CancelRegistrationRequest;
import com.coursescheduling.geektrust.domain.CommandParams;
import com.coursescheduling.geektrust.util.ApplicationUtil;
import com.coursescheduling.geektrust.util.ValidationUtil;
import com.coursescheduling.geektrust.domain.AddCourseRequest;
import com.coursescheduling.geektrust.domain.AllotCourseRequest;
import com.coursescheduling.geektrust.domain.Command;
import com.coursescheduling.geektrust.domain.RegisterCourseRequest;
import com.coursescheduling.geektrust.exceptions.InvalidInputException;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import static com.coursescheduling.geektrust.helper.Constants.BLANK_SPACE;
import static com.coursescheduling.geektrust.helper.Constants.FIRST_INDEX;
import static com.coursescheduling.geektrust.helper.Constants.INPUT_DATA_ERROR;

public class CommandProcessorService {

    private static final Integer INDEXES_TO_SKIP = 1;
    public Command parseCommandLine(String inputCommand) throws InvalidInputException {
        if (inputCommand.isEmpty()) {
            return null;
        }
        inputCommand = inputCommand.trim();
        ValidationUtil.validateInputString(inputCommand);
        return getCommandFromInputString(inputCommand);
    }

    public void executeCommand(Command command) throws InvalidInputException {
        if (Objects.isNull(command)) {
            return;
        }
        CommandExecutorService commandExecutorService = ApplicationUtil.getServiceForCommand(command);
        if (Objects.isNull(commandExecutorService)) {
            throw new InvalidInputException(INPUT_DATA_ERROR);
        }
        try {
            commandExecutorService.executeCommand(command);
        }
        catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    private Command getCommandFromInputString(String inputStr) {
        String [] input = inputStr.split(BLANK_SPACE);
        Command command = Command.of(input[FIRST_INDEX]);
        List<String> params = Arrays.stream(input).skip(INDEXES_TO_SKIP).collect(Collectors.toList());
        command.setCommandParams(getCommandParams(command, params));
        return command;
    }

    private CommandParams getCommandParams(Command command, List<String> params) {
        AddCourseRequest addCourseRequest = null;
        AllotCourseRequest allotCourseRequest = null;
        RegisterCourseRequest registerCourseRequest = null;
        CancelRegistrationRequest cancelRegistrationRequest = null;
        switch (command) {
            case ADD_COURSE_OFFERING : {
                addCourseRequest = new AddCourseRequest(params);
                break;
            }
            case ALLOT_COURSE : {
                allotCourseRequest = new AllotCourseRequest(params);
                break;
            }
            case REGISTER : {
                registerCourseRequest = new RegisterCourseRequest(params);
                break;
            }
            case CANCEL : {
                cancelRegistrationRequest = new CancelRegistrationRequest(params);
                break;
            }
        }
        return new CommandParams(addCourseRequest, allotCourseRequest, registerCourseRequest, cancelRegistrationRequest);
    }
}
