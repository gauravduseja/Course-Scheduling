package com.coursescheduling.geektrust.service;

import com.coursescheduling.geektrust.util.DateUtil;
import com.coursescheduling.geektrust.domain.Command;
import com.coursescheduling.geektrust.domain.Course;
import com.coursescheduling.geektrust.domain.Employee;
import com.coursescheduling.geektrust.repository.CourseSchedulingRepository;

import java.util.HashMap;
import java.util.Map;

import static com.coursescheduling.geektrust.helper.Constants.BLANK_SPACE;
import static com.coursescheduling.geektrust.helper.Constants.CONFIRMED;
import static com.coursescheduling.geektrust.helper.Constants.COURSE_CANCELED;

public class AllotCourseService implements CommandExecutorService {
    @Override
    public void executeCommand(Command command) {
        HashMap<String, Course> availableCourses = CourseSchedulingRepository.AVAILABLE_COURSES;

        String courseId = command.getCommandParams().getAllotCourseRequest().getCourseOfferingId();
        if (availableCourses.containsKey(courseId)) {
            Course course = availableCourses.get(courseId);
            if (course.getRegisteredEmployees().size() < course.getMinEmployee()) {
                course.setCancelled(true);
                availableCourses.remove(courseId);
            }
            else {
                course.setAllotted(true);
            }
            printCourseAllotmentDetails(course);
        }
    }

    private void printCourseAllotmentDetails(Course course) {
        String allotmentStatus = course.isCancelled() ? COURSE_CANCELED : CONFIRMED;

        for (Map.Entry<String, Employee> regIdVsEmp : course.getRegisteredEmployees().entrySet()) {
            Employee employee = regIdVsEmp.getValue();
            System.out.println(regIdVsEmp.getKey() + BLANK_SPACE + employee.getEmail() + BLANK_SPACE + course.getId() + BLANK_SPACE
                    + course.getTitle() + BLANK_SPACE + course.getInstructor() + BLANK_SPACE +
                    DateUtil.getFormattedDate(course.getDate(), DateUtil.DATE_TIME_FORMAT) + BLANK_SPACE + allotmentStatus);
        }
    }
}
