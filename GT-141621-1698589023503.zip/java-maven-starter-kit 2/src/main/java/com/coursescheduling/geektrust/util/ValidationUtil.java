package com.coursescheduling.geektrust.util;

import com.coursescheduling.geektrust.domain.Command;
import com.coursescheduling.geektrust.exceptions.InvalidInputException;


import java.util.Objects;

import static com.coursescheduling.geektrust.helper.Constants.BLANK_SPACE;
import static com.coursescheduling.geektrust.helper.Constants.FIRST_INDEX;
import static com.coursescheduling.geektrust.helper.Constants.INPUT_DATA_ERROR;
import static com.coursescheduling.geektrust.helper.Constants.VALID_EMAIL_ADDRESS_REGEX;


public final class ValidationUtil {

    public static void validateEmailAddress(String emailAddress) throws InvalidInputException {
        if (!VALID_EMAIL_ADDRESS_REGEX.matcher(emailAddress).matches()) {
            throw new InvalidInputException(INPUT_DATA_ERROR);
        }
    }

    public static void validateInputString(String inputStr) throws InvalidInputException {
        String [] input = inputStr.split(BLANK_SPACE);
        if (Objects.isNull(Command.of(input[FIRST_INDEX]))) {
            throw new InvalidInputException(INPUT_DATA_ERROR);
        }

        Command command = Command.of(input[FIRST_INDEX]);
        int requiredNumberOfArgs = command.getRequiredNumberOfArgs();
        int numberOfArgsProvided = input.length - 1;

        if (requiredNumberOfArgs != numberOfArgsProvided) {
            throw new InvalidInputException(INPUT_DATA_ERROR);
        }
    }
}
