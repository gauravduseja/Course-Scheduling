package com.coursescheduling.geektrust;

import com.coursescheduling.geektrust.domain.Command;
import com.coursescheduling.geektrust.exceptions.InvalidInputException;
import com.coursescheduling.geektrust.service.CommandProcessorService;
import com.coursescheduling.geektrust.service.FileProcessorService;

import java.io.BufferedReader;
import java.util.Objects;

import static com.coursescheduling.geektrust.helper.Constants.FIRST_INDEX;

public class LearningManagementSystem {

    public void run(String [] args) {
        try {
            FileProcessorService fileProcessorService = new FileProcessorService(args[FIRST_INDEX]);
            BufferedReader bufferedReader = fileProcessorService.getInputString();
            String inputStr = bufferedReader.readLine();

            CommandProcessorService commandProcessorService = new CommandProcessorService();
            while (Objects.nonNull(inputStr)) {
                try {
                    Command command = commandProcessorService.parseCommandLine(inputStr);
                    commandProcessorService.executeCommand(command);
                }
                catch (InvalidInputException e) {
                    System.out.println(e.getMessage());
                }
                finally {
                    inputStr = bufferedReader.readLine();

                }
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
}
