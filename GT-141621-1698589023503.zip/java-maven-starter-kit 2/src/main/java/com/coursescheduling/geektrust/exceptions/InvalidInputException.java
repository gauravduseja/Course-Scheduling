package com.coursescheduling.geektrust.exceptions;


public final class InvalidInputException extends Exception {

    public InvalidInputException(String exceptionMessage) {
        super(exceptionMessage);
    }
}
