package com.coursescheduling.geektrust.domain;

public class CommandParams {

    private final AddCourseRequest addCourseRequest;
    private final AllotCourseRequest allotCourseRequest;
    private final RegisterCourseRequest registerCourseRequest;
    private final CancelRegistrationRequest cancelRegistrationRequest;


    public CommandParams(AddCourseRequest addCourseRequest, AllotCourseRequest allotCourseRequest, RegisterCourseRequest registerCourseRequest, CancelRegistrationRequest cancelRegistrationRequest) {
        this.addCourseRequest = addCourseRequest;
        this.allotCourseRequest = allotCourseRequest;
        this.registerCourseRequest = registerCourseRequest;
        this.cancelRegistrationRequest = cancelRegistrationRequest;
    }

    public AddCourseRequest getAddCourseRequest() {
        return addCourseRequest;
    }

    public AllotCourseRequest getAllotCourseRequest() {
        return allotCourseRequest;
    }

    public RegisterCourseRequest getRegisterCourseRequest() {
        return registerCourseRequest;
    }

    public CancelRegistrationRequest getCancelRegistrationRequest() {
        return cancelRegistrationRequest;
    }
}
