package com.coursescheduling.geektrust.service;


import com.coursescheduling.geektrust.domain.Command;
import com.coursescheduling.geektrust.domain.Course;
import com.coursescheduling.geektrust.domain.Employee;
import com.coursescheduling.geektrust.domain.RegisterCourseRequest;
import com.coursescheduling.geektrust.domain.Registration;
import com.coursescheduling.geektrust.exceptions.CourseFullException;
import com.coursescheduling.geektrust.exceptions.InvalidInputException;
import com.coursescheduling.geektrust.repository.CourseSchedulingRepository;

import java.util.HashMap;

import static com.coursescheduling.geektrust.helper.Constants.ACCEPTED;
import static com.coursescheduling.geektrust.helper.Constants.BLANK_SPACE;
import static com.coursescheduling.geektrust.helper.Constants.DASH;

public class RegisterCourseService implements CommandExecutorService {

    private static final String COURSE_FULL_ERROR = "COURSE_FULL_ERROR";

    private static final String REG_COURSE = "REG-COURSE";
    @Override
    public void executeCommand(Command command) throws InvalidInputException, CourseFullException {
        RegisterCourseRequest registerCourseRequest = command.getCommandParams().getRegisterCourseRequest();
        String courseId = registerCourseRequest.getCourseOfferingId();
        Employee employee = new Employee(registerCourseRequest.getEmail());

        HashMap<String, Course> availableCourses = CourseSchedulingRepository.AVAILABLE_COURSES;

        if (availableCourses.containsKey(courseId)) {
            Course course = availableCourses.get(courseId);
            if (course.getRegisteredEmployees().size() == course.getMaxEmployee()) {
                throw new CourseFullException(COURSE_FULL_ERROR);
            }
            registerCourse(employee, course);
        }
    }

    private void registerCourse(Employee employee, Course course) {
        String registrationId = REG_COURSE + DASH + employee.getName() + DASH + course.getTitle();
        course.addRegisteredEmployee(registrationId, employee);
        Registration registration = new Registration(registrationId, course, employee);
        CourseSchedulingRepository.REGISTRATION_LIST.add(registration);
        System.out.println(registrationId + BLANK_SPACE + ACCEPTED);
    }

}
