package com.coursescheduling.geektrust.service;


import com.coursescheduling.geektrust.domain.Command;
import com.coursescheduling.geektrust.util.ValidationUtil;
import com.coursescheduling.geektrust.exceptions.InvalidInputException;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Objects;

import static com.coursescheduling.geektrust.helper.Constants.BLANK_SPACE;

public class FileProcessorService {
    private final BufferedReader bufferedReader;

    public FileProcessorService(String filePath) throws FileNotFoundException {
        File file = new File(filePath);
        this.bufferedReader = new BufferedReader(new FileReader(file));
    }

    public BufferedReader getInputString() {
        return bufferedReader;
    }
}
