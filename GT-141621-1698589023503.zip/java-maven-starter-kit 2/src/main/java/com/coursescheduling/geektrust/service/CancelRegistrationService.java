package com.coursescheduling.geektrust.service;

import com.coursescheduling.geektrust.domain.Command;
import com.coursescheduling.geektrust.domain.Registration;
import com.coursescheduling.geektrust.exceptions.InvalidInputException;
import com.coursescheduling.geektrust.repository.CourseSchedulingRepository;

import java.util.List;
import java.util.Optional;

import static com.coursescheduling.geektrust.helper.Constants.BLANK_SPACE;
import static com.coursescheduling.geektrust.helper.Constants.CANCEL_ACCEPTED;
import static com.coursescheduling.geektrust.helper.Constants.CANCEL_REJECTED;
import static com.coursescheduling.geektrust.helper.Constants.INPUT_DATA_ERROR;

public class CancelRegistrationService implements CommandExecutorService {

    @Override
    public void executeCommand(Command command) throws InvalidInputException {
        String registrationId = command.getCommandParams().getCancelRegistrationRequest().getCourseRegistrationId();
        List<Registration> registrationList = CourseSchedulingRepository.REGISTRATION_LIST;
        Optional<Registration> registrationOptional = registrationList.stream().filter(registration ->
                registrationId.equals(registration.getId())).findAny();

        if (!registrationOptional.isPresent()) {
            throw new InvalidInputException(INPUT_DATA_ERROR);
        }

        if (registrationOptional.get().getCourse().isAllotted()) {
            System.out.println(registrationId + BLANK_SPACE + CANCEL_REJECTED);
            return;
        }
        Registration registration = registrationOptional.get();
        registration.getCourse().getRegisteredEmployees().remove(registrationId);
        registrationList.remove(registrationOptional.get()); // remove the registration from registration list
        System.out.println(registrationId + BLANK_SPACE + CANCEL_ACCEPTED);
    }
}
