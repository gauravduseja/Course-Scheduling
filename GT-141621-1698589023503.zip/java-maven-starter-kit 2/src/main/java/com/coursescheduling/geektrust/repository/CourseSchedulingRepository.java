package com.coursescheduling.geektrust.repository;

import com.coursescheduling.geektrust.domain.Course;
import com.coursescheduling.geektrust.domain.Registration;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class CourseSchedulingRepository {

    public static HashMap<String, Course> AVAILABLE_COURSES = new HashMap<>();
    public static List<Registration> REGISTRATION_LIST = new ArrayList<>();
}
