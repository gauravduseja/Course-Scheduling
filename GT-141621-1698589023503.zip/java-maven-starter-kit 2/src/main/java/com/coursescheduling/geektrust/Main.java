package com.coursescheduling.geektrust;

import java.io.FileNotFoundException;

import static com.coursescheduling.geektrust.helper.Constants.UNSUPPORTED_INPUT_FILE;

public class Main {
    public static void main(String[] args) throws FileNotFoundException {
        if (args.length != 1) {
            throw new FileNotFoundException(UNSUPPORTED_INPUT_FILE);
        }
        LearningManagementSystem learningManagementSystem = new LearningManagementSystem();
        learningManagementSystem.run(args);
    }
}
