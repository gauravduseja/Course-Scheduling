package com.coursescheduling.geektrust.service;

import com.coursescheduling.geektrust.util.ApplicationUtil;
import com.coursescheduling.geektrust.domain.Command;
import com.coursescheduling.geektrust.domain.Course;
import com.coursescheduling.geektrust.domain.Employee;
import com.coursescheduling.geektrust.domain.Registration;
import com.coursescheduling.geektrust.exceptions.InvalidInputException;
import com.coursescheduling.geektrust.repository.CourseSchedulingRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.Date;
import java.util.Objects;

import static junit.framework.Assert.assertEquals;

public class CancelRegistrationServiceTest {

    private static final Integer MIN_EMPLOYEE = 1; // minimum number of employees that needs to be registered for the course
    private static final Integer MAX_EMPLOYEE = 2; // maximum number of employee that can register for the course

    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    private final CommandProcessorService commandProcessorService = new CommandProcessorService();

    private CourseSchedulingRepository repository;

    @BeforeEach
    public void setup() throws InvalidInputException {
        System.setOut(new PrintStream(outContent));
        Course course = new Course("OFFERING-JAVA-JAMES", "JAVA", "JAMES", new Date(), MIN_EMPLOYEE,
                MAX_EMPLOYEE, false, false);
        CourseSchedulingRepository.AVAILABLE_COURSES.put("OFFERING-JAVA-JAMES", course);
        Registration registration = new Registration("REG-COURSE-MOCKNAME-JAVA", course, new Employee("MOCKNAME@GMAIL.COM"));
        CourseSchedulingRepository.REGISTRATION_LIST.add(registration);

    }

    @Test
    void cancelRegistrationServiceTest() throws InvalidInputException {
        Command command = commandProcessorService.parseCommandLine("CANCEL REG-COURSE-MOCKNAME-JAVA");
        Assertions.assertDoesNotThrow(() -> Objects.requireNonNull(ApplicationUtil.getServiceForCommand(command)).executeCommand(command));
        assertEquals("REG-COURSE-MOCKNAME-JAVA CANCEL_ACCEPTED", outContent.toString().trim());
    }
}
