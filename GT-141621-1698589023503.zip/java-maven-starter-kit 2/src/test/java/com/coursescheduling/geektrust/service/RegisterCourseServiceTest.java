package com.coursescheduling.geektrust.service;

import com.coursescheduling.geektrust.domain.Command;
import com.coursescheduling.geektrust.domain.Course;
import com.coursescheduling.geektrust.exceptions.InvalidInputException;
import com.coursescheduling.geektrust.repository.CourseSchedulingRepository;
import com.coursescheduling.geektrust.util.ApplicationUtil;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.Date;
import java.util.Objects;

import static junit.framework.Assert.assertEquals;

public class RegisterCourseServiceTest {

    private static final Integer MIN_EMPLOYEE = 1; // minimum number of employees that needs to be registered for the course
    private static final Integer MAX_EMPLOYEE = 2; // maximum number of employee that can register for the course
    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    private final CommandProcessorService commandProcessorService = new CommandProcessorService();

    @BeforeEach
    public void setup() {
        System.setOut(new PrintStream(outContent));
        Course course = new Course("OFFERING-JAVA-JAMES", "JAVA", "JAMES", new Date(), MIN_EMPLOYEE,
                MAX_EMPLOYEE, false, false);
        CourseSchedulingRepository.AVAILABLE_COURSES.put("OFFERING-JAVA-JAMES", course);

    }

    @Test
    public void registerCourseServiceImplTest() throws InvalidInputException {
        Command command = commandProcessorService.parseCommandLine("REGISTER ANDY@GMAIL.COM OFFERING-JAVA-JAMES");
        Assertions.assertDoesNotThrow(() -> Objects.requireNonNull(ApplicationUtil.getServiceForCommand(command)).executeCommand(command));
        assertEquals("REG-COURSE-ANDY-JAVA ACCEPTED", outContent.toString().trim());
    }
}
