package com.coursescheduling.geektrust.service;


import com.coursescheduling.geektrust.domain.Command;
import com.coursescheduling.geektrust.util.ApplicationUtil;
import com.coursescheduling.geektrust.exceptions.InvalidInputException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import static junit.framework.Assert.assertEquals;

public class AddCourseServiceTest {

    private Command command;
    private CommandExecutorService commandExecutorService;
    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    private final CommandProcessorService commandProcessorService = new CommandProcessorService();

    @BeforeEach
    public void setUp() throws InvalidInputException {
        System.setOut(new PrintStream(outContent));
        command = commandProcessorService.parseCommandLine("ADD-COURSE-OFFERING JAVA JAMES 15062022 1 2");
        commandExecutorService = ApplicationUtil.getServiceForCommand(command);
    }

    @Test
    void addCourseSuccessTest() {
       Assertions.assertDoesNotThrow(() -> commandExecutorService.executeCommand(command));
       assertEquals("OFFERING-JAVA-JAMES", outContent.toString().trim());
    }
}
