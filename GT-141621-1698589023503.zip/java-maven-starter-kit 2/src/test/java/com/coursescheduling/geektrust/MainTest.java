package com.coursescheduling.geektrust;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.PrintStream;

import static org.junit.jupiter.api.Assertions.assertFalse;

public class MainTest {

    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();

    @BeforeEach
    public void setUp(){
        System.setOut(new PrintStream(outContent));
    }
    @Test
    public void testMain() throws FileNotFoundException {
        Main.main(new String[]{
                "sample_input/input1.txt"
        });
        assertFalse(outContent.toString().trim().isEmpty());
    }
}